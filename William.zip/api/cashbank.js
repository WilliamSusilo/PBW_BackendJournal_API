const jsreport = require("jsreport")({
  tempDirectory: require("os").tmpdir(),
  useSandbox: false,
  extensions: {
    express: { enabled: false },
    authentication: { enabled: false },
    authorization: { enabled: false },
  },
});

const { getSupabaseWithToken } = require("../lib/supabaseClient");
const Cors = require("cors");

const formidable = require("formidable");

// Disable default bodyParser only for file-upload use-case
module.exports.config = {
  api: {
    bodyParser: false,
  },
};

// Initialization for middleware CORS
const cors = Cors({
  methods: ["GET", "POST", "OPTIONS", "PATCH", "PUT", "DELETE"],
  origin: ["http://localhost:8080", "http://192.168.100.3:8080", "https://prabaraja-webapp.vercel.app"],
  allowedHeaders: ["Content-Type", "Authorization"],
});

// Helper for run middleware with async
function runMiddleware(req, res, fn) {
  return new Promise((resolve, reject) => {
    fn(req, res, (result) => {
      if (result instanceof Error) {
        return reject(result);
      }
      return resolve(result);
    });
  });
}

module.exports = async (req, res) => {
  await runMiddleware(req, res, cors);

  if (req.method === "OPTIONS") {
    return res.status(200).end();
  }

  const { method, headers, query } = req;
  let body = {};
  let files = {};
  let action = method === "GET" ? query.action : null;

  if (method !== "GET" && headers["content-type"]?.includes("multipart/form-data")) {
    const form = new formidable.IncomingForm({ keepExtensions: true });

    try {
      const { fields, files: parsedFiles } = await new Promise((resolve, reject) => {
        form.parse(req, (err, fields, files) => {
          if (err) reject(err);
          else resolve({ fields, files });
        });
      });

      // Normalize fields so they are not arrays
      for (const key in fields) {
        body[key] = Array.isArray(fields[key]) ? fields[key][0] : fields[key];
      }

      files = parsedFiles;
      action = body.action;

      // Save to req so it can be used in handler
      req.body = body;
      req.files = files;
      console.log("Files:", req.files);
    } catch (err) {
      return res.status(400).json({ error: true, message: "Error parsing form-data: " + err.message });
    }
  } else if (method !== "GET") {
    body = req.body;
    action = body.action;
  }

  try {
    switch (action) {
      // Add Account Endpoint
      case "addAccount": {
        if (method !== "POST") {
          return res.status(405).json({ error: true, message: "Method not allowed. Use POST for addAccount." });
        }

        const authHeader = req.headers.authorization;
        if (!authHeader) return res.status(401).json({ error: true, message: "No authorization header provided" });

        const token = authHeader.split(" ")[1];
        const supabase = getSupabaseWithToken(token);

        const {
          data: { user },
          error: userError,
        } = await supabase.auth.getUser();

        if (userError || !user) return res.status(401).json({ error: true, message: "Invalid or expired token" });

        // // Get user roles from database (e.g. 'profiles' or 'users' table)
        // const { data: userProfile, error: profileError } = await supabase.from("profiles").select("role").eq("id", user.id).single();

        // if (profileError || !userProfile) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Unable to fetch user role or user not found",
        //   });
        // }

        // // Check if the user role is among those permitted
        // const allowedRoles = ["finance", "accounting", "manager", "admin"];
        // if (!allowedRoles.includes(userProfile.role.toLowerCase())) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Access denied. You are not authorized to perform this action.",
        //   });
        // }

        const { account_name, account_type, bank_name, bank_number, balance, type } = req.body;

        if (!account_name || !account_type || !bank_name || !bank_number || !balance || !type) {
          return res.status(400).json({ error: true, message: "Missing required fields" });
        }

        const { data: maxNumberData, error: fetchError } = await supabase.from("cashbank").select("number").order("number", { ascending: false }).limit(1);

        if (fetchError) {
          return res.status(500).json({ error: true, message: "Failed to fetch latest account number: " + fetchError.message });
        }

        let newNumber = 1;
        if (maxNumberData && maxNumberData.length > 0) {
          newNumber = maxNumberData[0].number + 1;
        }

        const { error: insertError } = await supabase.from("cashbank").insert([
          {
            user_id: user.id,
            account_name,
            number: newNumber,
            account_type,
            bank_name,
            bank_number,
            balance: Number(balance),
            status: "Active",
            type,
          },
        ]);

        if (insertError) {
          return res.status(500).json({ error: true, message: "Failed to add account: " + insertError.message });
        }

        return res.status(201).json({ error: false, message: "Account added successfully" });
      }

      // Edit Account Endpoint
      case "editAccount": {
        if (method !== "PUT") {
          return res.status(405).json({ error: true, message: "Method not allowed. Use PUT for editAccount." });
        }

        const authHeader = req.headers.authorization;
        if (!authHeader) return res.status(401).json({ error: true, message: "No authorization header provided" });

        const token = authHeader.split(" ")[1];
        const supabase = getSupabaseWithToken(token);

        const {
          data: { user },
          error: userError,
        } = await supabase.auth.getUser();

        if (userError || !user) return res.status(401).json({ error: true, message: "Invalid or expired token" });

        // // Get user roles from database (e.g. 'profiles' or 'users' table)
        // const { data: userProfile, error: profileError } = await supabase.from("profiles").select("role").eq("id", user.id).single();

        // if (profileError || !userProfile) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Unable to fetch user role or user not found",
        //   });
        // }

        // // Check if the user role is among those permitted
        // const allowedRoles = ["finance", "accounting", "manager", "admin"];
        // if (!allowedRoles.includes(userProfile.role.toLowerCase())) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Access denied. You are not authorized to perform this action.",
        //   });
        // }

        const { id, account_name, account_type, bank_name, bank_number, balance, type } = req.body;

        if (!id) {
          return res.status(400).json({ error: true, message: "Missing required fields" });
        }

        const { error: updateError } = await supabase
          .from("cashbank")
          .update({
            account_name,
            account_type,
            bank_name,
            bank_number,
            balance: Number(balance),
            type,
          })
          .eq("id", id);

        if (updateError) {
          return res.status(500).json({ error: true, message: "Failed to update account: " + updateError.message });
        }

        return res.status(200).json({ error: false, message: "Account updated successfully" });
      }

      // Archive and Unarchive Account Endpoint
      case "archiveAccount":
      case "unarchiveAccount": {
        if (method !== "PATCH") {
          return res.status(405).json({ error: true, message: `Method not allowed. Use PATCH for ${action}.` });
        }

        const authHeader = req.headers.authorization;
        if (!authHeader) return res.status(401).json({ error: true, message: "No authorization header provided" });

        const token = authHeader.split(" ")[1];
        const supabase = getSupabaseWithToken(token);

        const {
          data: { user },
          error: userError,
        } = await supabase.auth.getUser();

        if (userError || !user) return res.status(401).json({ error: true, message: "Invalid or expired token" });

        // // Get user roles from database (e.g. 'profiles' or 'users' table)
        // const { data: userProfile, error: profileError } = await supabase.from("profiles").select("role").eq("id", user.id).single();

        // if (profileError || !userProfile) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Unable to fetch user role or user not found",
        //   });
        // }

        // // Check if the user role is among those permitted
        // const allowedRoles = ["finance", "accounting", "manager", "admin"];
        // if (!allowedRoles.includes(userProfile.role.toLowerCase())) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Access denied. You are not authorized to perform this action.",
        //   });
        // }

        const { id } = req.body;

        if (!id) {
          return res.status(400).json({ error: true, message: "Missing required field: ID" });
        }

        const entityname = action === "archiveAccount" ? "Archive" : "Active";

        // Update status to 'Archive' or 'Unarchive'
        const { error: updateError } = await supabase.from("cashbank").update({ status: entityname }).eq("id", id);

        if (updateError) {
          return res.status(500).json({ error: true, message: `Failed to ${entityname} account: ` + updateError.message });
        }

        return res.status(200).json({ error: false, message: `Account ${entityname} successfully` });
      }

      // Delete Account Endpoint (only if status is Archive)
      case "deleteAccount": {
        if (method !== "DELETE") {
          return res.status(405).json({ error: true, message: "Method not allowed. Use DELETE for deleteAccount." });
        }

        const authHeader = req.headers.authorization;
        if (!authHeader) {
          return res.status(401).json({ error: true, message: "No authorization header provided" });
        }

        const token = authHeader.split(" ")[1];
        const supabase = getSupabaseWithToken(token);

        const {
          data: { user },
          error: userError,
        } = await supabase.auth.getUser();

        if (userError || !user) {
          return res.status(401).json({ error: true, message: "Invalid or expired token" });
        }

        // // Get user roles from database (e.g. 'profiles' or 'users' table)
        // const { data: userProfile, error: profileError } = await supabase.from("profiles").select("role").eq("id", user.id).single();

        // if (profileError || !userProfile) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Unable to fetch user role or user not found",
        //   });
        // }

        // // Check if the user role is among those permitted
        // const allowedRoles = ["finance", "accounting", "manager", "admin"];
        // if (!allowedRoles.includes(userProfile.role.toLowerCase())) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Access denied. You are not authorized to perform this action.",
        //   });
        // }

        const { id } = req.body;

        if (!id) {
          return res.status(400).json({ error: true, message: "Missing account ID" });
        }

        // Check if the account exists and is archived
        const { data: account, error: fetchError } = await supabase.from("cashbank").select("id, status").eq("id", id).single();

        if (fetchError) {
          return res.status(404).json({ error: true, message: "Account not found or you don't have permission" });
        }

        if (account.status !== "Archive") {
          return res.status(400).json({ error: true, message: "Only archived accounts can be deleted" });
        }

        const { error: deleteError } = await supabase.from("cashbank").delete().eq("id", id);

        if (deleteError) {
          return res.status(500).json({ error: true, message: "Failed to delete account: " + deleteError.message });
        }

        return res.status(200).json({ error: false, message: "Account deleted successfully" });
      }

      // Get Bank Accounts Endpoint
      case "getAccounts": {
        if (method !== "GET") {
          return res.status(405).json({ error: true, message: "Method not allowed. Use GET for getAccounts." });
        }

        const authHeader = req.headers.authorization;
        if (!authHeader) {
          return res.status(401).json({ error: true, message: "No authorization header provided" });
        }

        const token = authHeader.split(" ")[1];
        const supabase = getSupabaseWithToken(token);

        const {
          data: { user },
          error: userError,
        } = await supabase.auth.getUser();

        if (userError || !user) {
          return res.status(401).json({ error: true, message: "Invalid or expired token" });
        }

        // // Get user roles from database (e.g. 'profiles' or 'users' table)
        // const { data: userProfile, error: profileError } = await supabase.from("profiles").select("role").eq("id", user.id).single();

        // if (profileError || !userProfile) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Unable to fetch user role or user not found",
        //   });
        // }

        // // Check if the user role is among those permitted
        // const allowedRoles = ["finance", "accounting", "manager", "admin"];
        // if (!allowedRoles.includes(userProfile.role.toLowerCase())) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Access denied. You are not authorized to perform this action.",
        //   });
        // }

        const { status } = req.query;
        const search = req.query.search?.toLowerCase();
        const pagination = parseInt(req.query.page) || 1;
        const limitValue = parseInt(req.query.limit) || 10;
        const from = (pagination - 1) * limitValue;
        const to = from + limitValue - 1;

        let query = supabase.from("cashbank").select("*").order("created_at", { ascending: false }).eq("status", status).range(from, to);

        if (search) {
          const stringColumns = ["account_name", "account_type", "bank_name", "bank_number", "type"];

          const ilikeConditions = stringColumns.map((col) => `${col}.ilike.%${search}%`);
          const eqIntConditions = [];
          const eqFloatConditions = [];

          if (!isNaN(search) && Number.isInteger(Number(search))) {
            eqIntConditions.push("number.eq." + Number(search));
          }

          if (!isNaN(search) && !Number.isNaN(parseFloat(search))) {
            eqFloatConditions.push("balance.eq." + parseFloat(search));
          }

          const codeMatch = search.match(/^BANK-?0*(\d{5,})$/i);
          if (codeMatch) {
            const extractedNumber = parseInt(codeMatch[1], 10);
            if (!isNaN(extractedNumber)) {
              eqIntConditions.push("number.eq." + extractedNumber);
            }
          }

          const searchConditions = [...ilikeConditions, ...eqIntConditions, ...eqFloatConditions].join(",");
          query = query.or(searchConditions);
        }

        const { data: accounts, error: fetchError } = await query;

        if (fetchError) {
          return res.status(500).json({ error: true, message: "Failed to fetch accounts: " + fetchError.message });
        }

        const formattedData = accounts.map((item) => ({
          ...item,
          number: `${"BANK-"}${String(item.number).padStart(5, "0")}`,
        }));

        return res.status(200).json({ error: false, data: formattedData });
      }

      // Get Debit Balance Endpoint
      case "getDebitBalance": {
        if (method !== "GET") {
          return res.status(405).json({ error: true, message: "Method not allowed. Use GET for getDebitBalance." });
        }

        const authHeader = req.headers.authorization;
        if (!authHeader) return res.status(401).json({ error: true, message: "No authorization header provided" });

        const token = authHeader.split(" ")[1];
        const supabase = getSupabaseWithToken(token);

        const {
          data: { user },
          error: userError,
        } = await supabase.auth.getUser();

        if (userError || !user) return res.status(401).json({ error: true, message: "Invalid or expired token" });

        // // Get user roles from database (e.g. 'profiles' or 'users' table)
        // const { data: userProfile, error: profileError } = await supabase.from("profiles").select("role").eq("id", user.id).single();

        // if (profileError || !userProfile) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Unable to fetch user role or user not found",
        //   });
        // }

        // // Check if the user role is among those permitted
        // const allowedRoles = ["finance", "accounting", "manager", "admin"];
        // if (!allowedRoles.includes(userProfile.role.toLowerCase())) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Access denied. You are not authorized to perform this action.",
        //   });
        // }

        const { data: debitAccounts, error: debitError } = await supabase.from("cashbank").select("balance").eq("account_type", "Debit").eq("status", "Active");

        if (debitError) {
          return res.status(500).json({ error: true, message: "Failed to fetch debit balance: " + debitError.message });
        }

        const totalDebitBalance = debitAccounts.reduce((sum, acc) => sum + parseFloat(acc.balance || 0), 0);

        return res.status(200).json({ error: false, total_debit_balance: totalDebitBalance });
      }

      // Get Credit Balance Endpoint
      case "getCreditBalance": {
        if (method !== "GET") {
          return res.status(405).json({ error: true, message: "Method not allowed. Use GET for getCreditBalance." });
        }

        const authHeader = req.headers.authorization;
        if (!authHeader) return res.status(401).json({ error: true, message: "No authorization header provided" });

        const token = authHeader.split(" ")[1];
        const supabase = getSupabaseWithToken(token);

        const {
          data: { user },
          error: userError,
        } = await supabase.auth.getUser();

        if (userError || !user) return res.status(401).json({ error: true, message: "Invalid or expired token" });

        // // Get user roles from database (e.g. 'profiles' or 'users' table)
        // const { data: userProfile, error: profileError } = await supabase.from("profiles").select("role").eq("id", user.id).single();

        // if (profileError || !userProfile) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Unable to fetch user role or user not found",
        //   });
        // }

        // // Check if the user role is among those permitted
        // const allowedRoles = ["finance", "accounting", "manager", "admin"];
        // if (!allowedRoles.includes(userProfile.role.toLowerCase())) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Access denied. You are not authorized to perform this action.",
        //   });
        // }

        const { data: creditAccounts, error: creditError } = await supabase.from("cashbank").select("balance").eq("account_type", "Credit").eq("status", "Active");

        if (creditError) {
          return res.status(500).json({ error: true, message: "Failed to fetch credit balance: " + creditError.message });
        }

        const totalCreditBalance = creditAccounts.reduce((sum, acc) => sum + parseFloat(acc.balance || 0), 0);

        return res.status(200).json({ error: false, total_credit_balance: totalCreditBalance });
      }

      case "transferFunds": {
        if (method !== "POST") {
          return res.status(405).json({ error: true, message: "Method not allowed. Use POST." });
        }

        const authHeader = req.headers.authorization;
        if (!authHeader) return res.status(401).json({ error: true, message: "No authorization header provided" });

        const token = authHeader.split(" ")[1];
        const supabase = getSupabaseWithToken(token);

        const {
          data: { user },
          error: userError,
        } = await supabase.auth.getUser();

        if (userError || !user) return res.status(401).json({ error: true, message: "Invalid or expired token" });

        // // Get user roles from database (e.g. 'profiles' or 'users' table)
        // const { data: userProfile, error: profileError } = await supabase.from("profiles").select("role").eq("id", user.id).single();

        // if (profileError || !userProfile) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Unable to fetch user role or user not found",
        //   });
        // }

        // // Check if the user role is among those permitted
        // const allowedRoles = ["finance", "accounting", "manager", "admin"];
        // if (!allowedRoles.includes(userProfile.role.toLowerCase())) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Access denied. You are not authorized to perform this action.",
        //   });
        // }

        const { from_account_id, to_account_id, amount, notes } = req.body;

        if (!from_account_id || !to_account_id || !amount) {
          return res.status(400).json({ error: true, message: "Missing required fields" });
        }

        if (from_account_id === to_account_id) {
          return res.status(400).json({ error: true, message: "From and To accounts must be different" });
        }

        const amountValue = parseFloat(amount);
        if (isNaN(amountValue) || amountValue <= 0) {
          return res.status(400).json({ error: true, message: "Invalid transfer amount" });
        }

        const { data: fromAccount, error: fromError } = await supabase.from("cashbank").select("balance").eq("id", from_account_id).single();
        const { data: toAccount, error: toError } = await supabase.from("cashbank").select("balance").eq("id", to_account_id).single();

        if (fromError || toError || !fromAccount || !toAccount) {
          return res.status(404).json({ error: true, message: "Source or destination account not found" });
        }

        if (Number(amount) > Number(fromAccount.balance)) {
          return res.status(400).json({ error: true, message: "Insufficient balance in from account" });
        }

        // Balance before
        const fromBefore = Number(fromAccount.balance);
        const toBefore = Number(toAccount.balance);

        // Balance after
        const fromAfter = fromBefore - Number(amount);
        const toAfter = toBefore + Number(amount);

        // Update balance
        const { error: deductError } = await supabase.from("cashbank").update({ balance: fromAfter }).eq("id", from_account_id);
        const { error: addError } = await supabase.from("cashbank").update({ balance: toAfter }).eq("id", to_account_id);

        if (deductError || addError) {
          return res.status(500).json({ error: true, message: "Failed to transfer funds" });
        }

        // Record the transaction
        const { data: maxNumberData, error: fetchError } = await supabase.from("bank_transfer_transactions").select("number").order("number", { ascending: false }).limit(1);

        if (fetchError) {
          return res.status(500).json({ error: true, message: "Failed to fetch latest transfer transaction: " + fetchError.message });
        }

        let newNumber = 1;
        if (maxNumberData && maxNumberData.length > 0) {
          newNumber = maxNumberData[0].number + 1;
        }

        // Save the transactions data
        const { error: insertError } = await supabase.from("bank_transfer_transactions").insert([
          {
            user_id: user.id,
            number: newNumber,
            from_account: from_account_id,
            to_account: to_account_id,
            amount: Number(amount),
            notes,
            source_balance_before: fromBefore,
            source_balance_after: toBefore,
            target_balance_before: fromAfter,
            target_balance_after: toAfter,
          },
        ]);

        if (insertError) {
          return res.status(500).json({ error: true, message: "Failed to create transfer: " + insertError.message });
        }

        return res.status(201).json({ error: false, message: "Transfer recorded successfully" });
      }

      // Receive Money Endpoint
      case "receiveMoney": {
        if (method !== "POST") {
          return res.status(405).json({ error: true, message: "Method not allowed. Use POST." });
        }

        const authHeader = req.headers.authorization;
        if (!authHeader) return res.status(401).json({ error: true, message: "No authorization header provided" });

        const token = authHeader.split(" ")[1];
        const supabase = getSupabaseWithToken(token);

        const {
          data: { user },
          error: userError,
        } = await supabase.auth.getUser();

        if (userError || !user) {
          return res.status(401).json({ error: true, message: "Invalid or expired token" });
        }

        // // Get user roles from database (e.g. 'profiles' or 'users' table)
        // const { data: userProfile, error: profileError } = await supabase.from("profiles").select("role").eq("id", user.id).single();

        // if (profileError || !userProfile) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Unable to fetch user role or user not found",
        //   });
        // }

        // // Check if the user role is among those permitted
        // const allowedRoles = ["finance", "accounting", "manager", "admin"];
        // if (!allowedRoles.includes(userProfile.role.toLowerCase())) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Access denied. You are not authorized to perform this action.",
        //   });
        // }

        const { receiving_account_id, amount, payer_name, reference, date_received, notes } = req.body;

        const proofFile = req.files?.proof_file;
        let proof_url = null;

        // Upload proof of transfer if any
        if (proofFile) {
          const fs = require("fs/promises");
          const path = require("path");

          const proofFileArray = req.files?.proof_file;
          const proofFile = Array.isArray(proofFileArray) ? proofFileArray[0] : proofFileArray;

          if (!proofFile || !proofFile.filepath) {
            return res.status(400).json({ error: true, message: "No proof file uploaded" });
          }

          const filePath = proofFile.filepath;

          console.log("Proof file:", proofFile);
          console.log("File path:", proofFile?.filepath);

          const fileBuffer = await fs.readFile(filePath);
          const fileExt = path.extname(proofFile.originalFilename || ".png");
          const fileName = `cashbankReceiveMoney/${user.id}_${Date.now()}${fileExt}`;

          const { data: uploadData, error: uploadError } = await supabase.storage.from("private").upload(fileName, fileBuffer, {
            contentType: proofFile.mimetype || "image/png",
            upsert: false,
          });

          if (uploadError) {
            return res.status(500).json({ error: true, message: "Failed to upload proof: " + uploadError.message });
          }

          proof_url = uploadData.path;
        }

        if (!receiving_account_id || !amount || !payer_name || !date_received) {
          return res.status(400).json({ error: true, message: "Missing required fields" });
        }

        const amountValue = parseFloat(amount);
        if (isNaN(amountValue) || amountValue <= 0) {
          return res.status(400).json({ error: true, message: "Invalid received amount" });
        }

        const { data: toAccount, error: toError } = await supabase.from("cashbank").select("balance").eq("id", receiving_account_id).single();

        if (toError || !toAccount) {
          return res.status(404).json({ error: true, message: "Receiving account not found" });
        }

        const toBefore = Number(toAccount.balance);
        const toAfter = toBefore + amountValue;

        const { error: updateError } = await supabase.from("cashbank").update({ balance: toAfter }).eq("id", receiving_account_id);

        if (updateError) {
          return res.status(500).json({ error: true, message: "Failed to update balance: " + updateError.message });
        }

        // Record the transaction
        const { data: maxNumberData, error: fetchError } = await supabase.from("bank_receive_transactions").select("number").order("number", { ascending: false }).limit(1);

        if (fetchError) {
          return res.status(500).json({ error: true, message: "Failed to fetch latest receive transaction: " + fetchError.message });
        }

        let newNumber = 1;
        if (maxNumberData && maxNumberData.length > 0) {
          newNumber = maxNumberData[0].number + 1;
        }

        const { error: insertError } = await supabase.from("bank_receive_transactions").insert([
          {
            user_id: user.id,
            number: newNumber,
            receiving_account: receiving_account_id,
            amount: amountValue,
            payer_name,
            reference,
            date_received,
            notes,
            proof_url,
            target_balance_before: toBefore,
            target_balance_after: toAfter,
          },
        ]);

        if (insertError) {
          return res.status(500).json({ error: true, message: "Failed to record received money: " + insertError.message });
        }

        return res.status(201).json({ error: false, message: "Received money recorded successfully" });
      }

      // Get All Transfer Money Endpoint
      case "getTransfers": {
        if (method !== "GET") {
          return res.status(405).json({ error: true, message: "Method not allowed. Use GET." });
        }

        const authHeader = req.headers.authorization;
        if (!authHeader) return res.status(401).json({ error: true, message: "No authorization header provided" });

        const token = authHeader.split(" ")[1];
        const supabase = getSupabaseWithToken(token);

        const {
          data: { user },
          error: userError,
        } = await supabase.auth.getUser();

        if (userError || !user) return res.status(401).json({ error: true, message: "Invalid or expired token" });

        // // Get user roles from database (e.g. 'profiles' or 'users' table)
        // const { data: userProfile, error: profileError } = await supabase.from("profiles").select("role").eq("id", user.id).single();

        // if (profileError || !userProfile) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Unable to fetch user role or user not found",
        //   });
        // }

        // // Check if the user role is among those permitted
        // const allowedRoles = ["finance", "accounting", "manager", "admin"];
        // if (!allowedRoles.includes(userProfile.role.toLowerCase())) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Access denied. You are not authorized to perform this action.",
        //   });
        // }

        const search = req.query.search?.toLowerCase();
        const pagination = parseInt(req.query.page) || 1;
        const limitValue = parseInt(req.query.limit) || 10;
        const from = (pagination - 1) * limitValue;
        const to = from + limitValue - 1;

        let query = supabase.from("bank_transfer_transactions").select("*").order("created_at", { ascending: false }).range(from, to);

        if (search) {
          const stringColumns = ["notes"];
          const uuidColumns = ["from_account", "to_account"];
          const numericColumns = ["amount", "source_balance_before", "source_balance_after", "target_balance_before", "target_balance_after"];

          const ilikeConditions = stringColumns.map((col) => `${col}.ilike.%${search}%`);

          // Validation if search is UUID
          const isValidUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(search);

          // Make condition for eq if UUID match
          const eqUUIDConditions = isValidUUID ? uuidColumns.map((col) => `${col}.eq.${search}`) : [];

          const eqIntConditions = [];
          const eqFloatConditions = [];

          if (!isNaN(search) && Number.isInteger(Number(search))) {
            eqIntConditions.push("number.eq." + Number(search));
          }

          if (!isNaN(search) && !Number.isNaN(parseFloat(search))) {
            const value = parseFloat(search);
            eqFloatConditions.push(...numericColumns.map((col) => `${col}.eq.${value}`));
          }

          const codeMatch = search.match(/^TRF-?0*(\d{5,})$/i);
          if (codeMatch) {
            const extractedNumber = parseInt(codeMatch[1], 10);
            if (!isNaN(extractedNumber)) {
              eqIntConditions.push("number.eq." + extractedNumber);
            }
          }

          const searchConditions = [...ilikeConditions, ...eqUUIDConditions, ...eqIntConditions, ...eqFloatConditions].join(",");
          query = query.or(searchConditions);
        }

        const { data: transfers, error: fetchError } = await query;

        if (fetchError) {
          return res.status(500).json({ error: true, message: "Failed to fetch transfers: " + fetchError.message });
        }

        const formattedData = transfers.map((item) => ({
          ...item,
          number: `${"TRF-"}${String(item.number).padStart(5, "0")}`,
        }));

        return res.status(200).json({ error: false, data: formattedData });
      }

      // Get All Receive Money Endpoint
      case "getReceives": {
        if (method !== "GET") {
          return res.status(405).json({ error: true, message: "Method not allowed. Use GET." });
        }

        const authHeader = req.headers.authorization;
        if (!authHeader) return res.status(401).json({ error: true, message: "No authorization header provided" });

        const token = authHeader.split(" ")[1];
        const supabase = getSupabaseWithToken(token);

        const {
          data: { user },
          error: userError,
        } = await supabase.auth.getUser();

        if (userError || !user) return res.status(401).json({ error: true, message: "Invalid or expired token" });

        // // Get user roles from database (e.g. 'profiles' or 'users' table)
        // const { data: userProfile, error: profileError } = await supabase.from("profiles").select("role").eq("id", user.id).single();

        // if (profileError || !userProfile) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Unable to fetch user role or user not found",
        //   });
        // }

        // // Check if the user role is among those permitted
        // const allowedRoles = ["finance", "accounting", "manager", "admin"];
        // if (!allowedRoles.includes(userProfile.role.toLowerCase())) {
        //   return res.status(403).json({
        //     error: true,
        //     message: "Access denied. You are not authorized to perform this action.",
        //   });
        // }

        const search = req.query.search?.toLowerCase();
        const pagination = parseInt(req.query.page) || 1;
        const limitValue = parseInt(req.query.limit) || 10;
        const from = (pagination - 1) * limitValue;
        const to = from + limitValue - 1;

        let query = supabase.from("bank_receive_transactions").select("*").order("created_at", { ascending: false }).range(from, to);

        if (search) {
          const stringColumns = ["payer_name", "reference", "notes"];
          const uuidColumns = ["receiving_account"];
          const numericColumns = ["amount", "target_balance_before", "target_balance_after"];

          const ilikeConditions = stringColumns.map((col) => `${col}.ilike.%${search}%`);

          // Validation if search is UUID
          const isValidUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(search);

          // Make condition for eq if UUID match
          const eqUUIDConditions = isValidUUID ? uuidColumns.map((col) => `${col}.eq.${search}`) : [];

          const eqIntConditions = [];
          const eqFloatConditions = [];

          if (!isNaN(search) && Number.isInteger(Number(search))) {
            eqIntConditions.push("number.eq." + Number(search));
          }

          if (!isNaN(search) && !Number.isNaN(parseFloat(search))) {
            const value = parseFloat(search);
            eqFloatConditions.push(...numericColumns.map((col) => `${col}.eq.${value}`));
          }

          const codeMatch = search.match(/^REC-?0*(\d{5,})$/i);
          if (codeMatch) {
            const extractedNumber = parseInt(codeMatch[1], 10);
            if (!isNaN(extractedNumber)) {
              eqIntConditions.push("number.eq." + extractedNumber);
            }
          }

          const searchConditions = [...ilikeConditions, ...eqUUIDConditions, ...eqIntConditions, ...eqFloatConditions].join(",");
          query = query.or(searchConditions);
        }

        const { data: receives, error: fetchError } = await query;

        if (fetchError) {
          return res.status(500).json({ error: true, message: "Failed to fetch receives: " + fetchError.message });
        }

        const formattedData = receives.map((item) => ({
          ...item,
          number: `${"REC-"}${String(item.number).padStart(5, "0")}`,
        }));

        return res.status(200).json({ error: false, data: formattedData });
      }

      // Export Transaction History PDF Endpoint
      case "exportTransactionHistoryPdf": {
        if (method !== "GET") {
          return res.status(405).json({
            error: true,
            message: "Method not allowed. Use GET.",
          });
        }

        // Check for Authorization header
        const authHeader = req.headers.authorization;
        if (!authHeader) {
          return res.status(401).json({
            error: true,
            message: "Authorization header is missing.",
          });
        }

        // Extract token and initialize Supabase client
        const token = authHeader.split(" ")[1];
        const supabase = getSupabaseWithToken(token);

        // Validate user session from token
        const {
          data: { user },
          error: userError,
        } = await supabase.auth.getUser(token);

        if (userError || !user) {
          return res.status(401).json({
            error: true,
            message: "Invalid or expired token.",
          });
        }

        // Get account_code from query params
        const accountCode = req.query.number;
        if (!accountCode) {
          return res.status(400).json({
            error: true,
            message: "Missing account_code",
          });
        }

        // Step 1: Find cashbank row based on account_code
        const { data: cashbankRow, error: cashbankError } = await supabase.from("cashbank").select("id, number, account_name").eq("number", accountCode).single();

        if (cashbankError || !cashbankRow) {
          return res.status(404).json({
            error: true,
            message: "Cashbank with given account_code not found",
          });
        }

        const cashbankId = cashbankRow.id;
        const bankName = cashbankRow.account_name;

        // Step 2: Find bank_receive_transactions where receiving_account = cashbankId
        const { data: transactions, error: transactionError } = await supabase
          .from("bank_receive_transactions")
          .select("date_received, payer_name, reference, amount")
          .eq("receiving_account", cashbankId)
          .order("date_received", { ascending: true });

        console.error(transactionError);

        if (transactionError) {
          return res.status(500).json({
            error: true,
            message: "Failed to fetch bank receive transactions",
          });
        }

        // Helper to format currency as IDR
        const formatCurrency = (amount) => `Rp ${Number(amount || 0).toLocaleString("id-ID")}`;

        // Helper to format date as dd MMM yyyy
        const formatDate = (date) =>
          new Date(date).toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "short",
            year: "numeric",
          });

        // Calculate total processed
        const totalProcessed = transactions.reduce((sum, t) => sum + (Number(t.amount) || 0), 0);

        // Build transaction rows for HTML table
        const transactionRows = transactions
          .map((t) => {
            return `
      <tr>
        <td>${formatDate(t.date_received) || "-"}</td>
        <td>${t.payer_name || "-"}</td>
        <td>${t.reference || "-"}</td>
        <td style="text-align:right;">${formatCurrency(t.amount)}</td>
      </tr>`;
          })
          .join("");

        // Determine transaction date range
        const startDate = transactions.length > 0 ? formatDate(transactions[0].date_received) : "-";
        const endDate = transactions.length > 0 ? formatDate(transactions[transactions.length - 1].date_received) : "-";

        // Build the HTML for PDF
        const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body {
          font-family: Arial, sans-serif;
          padding: 40px;
        }
        h1 {
          text-align: center;
          margin-bottom: 30px;
        }
        .info {
          margin-bottom: 20px;
        }
        .info p {
          margin: 4px 0;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 20px;
        }
        th, td {
          border: 1px solid #999;
          padding: 8px;
        }
        th {
          background-color: #f0f0f0;
        }
        .total {
          font-weight: bold;
          text-align: right;
        }
        .header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 30px;
        }
        .header h1 {
          margin: 0;
          font-size: 20px;
        }
        .header img {
          height: 40px;
        }
      </style>
    </head>
    <body>
      <div class="header">
        <h1>${bankName} - Transaction History Report</h1>
        <img src="https://placehold.co/100x40/png?text=Logo" alt="Bank Logo" />
      </div>
      <div class="info">
        <p><strong>Transaction Dates:</strong> ${startDate} — ${endDate}</p>
        <p><strong>Report Generated on:</strong> ${formatDate(new Date())}</p>
        <p><strong>Total Processed:</strong> ${formatCurrency(totalProcessed)}</p>
      </div>

      <table>
        <thead>
          <tr>
            <th>Date</th>
            <th>Description</th>
            <th>Reference</th>
            <th>Amount</th>
          </tr>
        </thead>
        <tbody>
          ${transactionRows || `<tr><td colspan="4" style="text-align:center;">No transactions available</td></tr>`}
          <tr>
            <td colspan="3" class="total">Total</td>
            <td class="total">${formatCurrency(totalProcessed)}</td>
          </tr>
        </tbody>
      </table>
    </body>
    </html>
  `;

        // Step 3: Generate the PDF
        try {
          const jsreportInstance = await jsreport.init();
          const pdfResponse = await jsreportInstance.render({
            template: {
              content: html,
              engine: "none",
              recipe: "chrome-pdf",
            },
          });

          res.setHeader("Content-Type", "application/pdf");
          res.setHeader("Content-Disposition", `inline; filename="transaction_history_${accountCode}.pdf"`);
          pdfResponse.stream.pipe(res);
        } catch (err) {
          console.error("PDF generation error:", err);
          res.status(500).json({
            error: true,
            message: "Failed to generate PDF.",
          });
        }

        break;
      }

      default:
        return res.status(400).json({ error: true, message: "Invalid action" });
    }
  } catch (error) {
    return res.status(500).json({ error: true, message: "Internal server error: " + error.message });
  }
};
